import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'students.dart';

class DropDown extends StatefulWidget {

  final String id;

  const DropDown({Key key, this.id}) : super(key: key);


  @override
  DropDownWidget createState() => DropDownWidget();

}

class DropDownWidget extends State<DropDown> {

  String dropdownValue = '1';

  List <String> spinnerItems = [
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
    '11',
    '12',
    '13'
  ] ;

  @override
  Widget build(BuildContext context) {
    var students = Provider.of<StudentModel>(context, listen:false).items;
    var student = Provider.of<StudentModel>(context, listen:false).get(widget.id);
    return Scaffold(
      body: Center(
        child :
        Column(children: <Widget>[

          DropdownButton<String>(
            value: dropdownValue,
            icon: Icon(Icons.arrow_drop_down),
            iconSize: 24,
            elevation: 16,
            style: TextStyle(color: Colors.black, fontSize: 18),
            underline: Container(
              height: 2,
              color: Colors.deepPurpleAccent,
            ),
            onChanged: (String data) {
              setState(() {
                dropdownValue = data;
              });
            },
            items: spinnerItems.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),

          Text('Week: ' + '$dropdownValue',

              style: TextStyle
                (fontSize: 22,
                  color: Colors.black)),
        ]),
      ),
    );
  }
}