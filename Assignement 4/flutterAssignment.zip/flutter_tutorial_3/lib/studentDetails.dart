import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'students.dart';


class StudentDetails extends StatefulWidget
{

  final String id;

  const StudentDetails({Key key, this.id}) : super(key: key);

  @override
  _StudentDetailsState createState() => _StudentDetailsState();
}

class _StudentDetailsState extends State<StudentDetails> {

  final _formKey = GlobalKey<FormState>();
  final titleController = TextEditingController();
  final yearController = TextEditingController();
  //final durationController = TextEditingController();

  @override
  Widget build(BuildContext context)
  {
    var movies = Provider.of<StudentModel>(context, listen:false).items;
    var movie = Provider.of<StudentModel>(context, listen:false).get(widget.id);

    var adding = movie == null;
    if (!adding) {
      titleController.text = movie.name;
      yearController.text = movie.student_id.toString();
      //durationController.text = movie.duration.toString();
    }

    return Scaffold(
        appBar: AppBar(
          title: Text(adding ? "Add Movie" : "Edit Movie"),
          actions: [
            IconButton(
              icon: Icon(Icons.delete_outline),
              onPressed: (){
              if (_formKey.currentState.validate())
              {
                  Provider.of<StudentModel>(context, listen:false).delete(movie.id);
                  print('Deleted student');
                  Navigator.pop(context);
              }
              },
            ),
          ],
        ),
        body: Padding(
            padding: EdgeInsets.all(8),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  if (adding == false) Text("Movie Index ${widget.id}"), //check out this dart syntax, lets us do an if as part of an argument list
                  Form(
                    key: _formKey,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: <Widget>[
                          TextFormField(
                            decoration: InputDecoration(labelText: "Name"),
                            controller: titleController,
                          ),
                          TextFormField(
                            decoration: InputDecoration(labelText: "Student Id"),
                            controller: yearController,
                          ),


                          ElevatedButton.icon(onPressed: () {
                            if (_formKey.currentState.validate())
                            {
                              if (adding)
                              {
                                movie = Student();
                              }

                              //update the movie object
                              movie.name = titleController.text;
                              movie.student_id = int.parse(yearController.text); //good code would validate these
                              //movie.duration = double.parse(durationController.text); //good code would validate these

                              //TODO: update the model
                              if (adding)
                                Provider.of<StudentModel>(context, listen:false).add(movie);
                              else
                                Provider.of<StudentModel>(context, listen:false).update(widget.id, movie);

                              //return to previous screen
                              Navigator.pop(context);
                            }
                          }, icon: Icon(Icons.save), label: Text("Save Values"))
                        ],
                      ),
                    ),
                  )
                ]
            )
        )
    );
  }
}

